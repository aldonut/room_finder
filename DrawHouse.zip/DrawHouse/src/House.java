import processing.core.PApplet;
import processing.core.PShape;

public class House {

	private PShape house;  // The PShape object representing the bases of the house
	private PShape window1; 
	private PShape window2; 
	private PShape door;
	public int x = 25;//makes it so the House resizes depending of x
	
	public void setup(PApplet drawer) {
	drawer.size(200, 200);
	  		house =drawer.createShape(drawer.RECT, 0, 0, x*5,x*7/2);
	  		house.setFill(drawer.color(0, 0, 255));
	  		window1 = drawer.createShape(drawer.RECT,0,0, x,x);
	  		window2 = drawer.createShape(drawer.RECT, 0,0, x,x);
	  		door = drawer.createShape(drawer.RECT,0,0,x,x*2);

	}	
	
	
	
	
	public void draw(PApplet drawer) {
		drawer.shape(house,x*3/2,x*3/2);
		drawer.shape(window1, x*2,x*2);
		drawer.shape(window2, x*5,x*2);
		drawer.shape(door, x*7/2,x*3);
		drawer.triangle(x*3/2,x*3/2,x*4,x/2,x*13/2,x*3/2);//roof
		
}	





}
