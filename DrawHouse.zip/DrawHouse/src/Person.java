import processing.core.PApplet;
public class Person extends PApplet {


	public void draw(PApplet drawer) {
		
		drawer.line(5,30,30,30);//left arm
		drawer.line(25, 25, 25, 50);//body of person
		drawer.line(30, 30, 50, 30);//right arm
		drawer.line(25, 50, 10, 75);//left leg
		drawer.line(25, 50, 45, 75);//right leg
		drawer.ellipse(25,10,25,25);//head
	}
	
}
