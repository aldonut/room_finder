import java.awt.Dimension;
import javax.swing.JFrame;
import processing.awt.PSurfaceAWT;
import processing.core.PApplet;
import processing.core.PShape;
import processing.event.MouseEvent;

public class DrawingSurface extends PApplet {

	int value = 0;
	private House house;
	private Person person;
	
	public DrawingSurface() {
		house = new House();
		person = new Person();
	}


	/*public void setUpMain() {
		house.setup(this);
	}
	*/
	public void mouseWheel(MouseEvent event) {
		  float e = event.getCount();
		  println(e);
		}

	
	public void draw() {
		house.setup(this);
		house.draw(this);
		person.draw(this);
		//if(keyPressed == true)
				

	}
	
	public void keyPressed() {
		//if(keyPressed == true)
				house.x ++;
	}
	
}
	
	
	
	
	
	
	
	
